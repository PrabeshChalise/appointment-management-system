<?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
            header("location: ../login.php");
        }else{
            $useremail=$_SESSION["user"];
        }

    }else{
        header("location: ../login.php");
    }

    include("../connection.php");

    $sqlmain = "SELECT * FROM patient WHERE pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s",$useremail);
    $stmt->execute();
    $userrow = $stmt->get_result();
    $userfetch = $userrow->fetch_assoc();
    $userid = $userfetch["pid"];
    $username = $userfetch["pname"];
    
    if($_POST){
        if(isset($_POST["booknow"])){
            
            $scheduleid = $_POST["scheduleid"];
            $date = $_POST["date"];

            // Check if the selected appointment time and date overlap with another patient's appointment
            $sql_overlap = "SELECT * FROM appointment WHERE scheduleid = ? AND appodate = ?";
            $stmt_overlap = $database->prepare($sql_overlap);
            $stmt_overlap->bind_param("is", $scheduleid, $date);
            $stmt_overlap->execute();
            $overlap_rows = $stmt_overlap->get_result();

            if ($overlap_rows->num_rows > 0) {
                // If there is an overlapping appointment, show a message to the patient
                header("location: appointment.php?action=booking-not2&titleget=none");
            } else {
                // Check if the patient already has an appointment scheduled for the selected date and time
                $sql_existing = "SELECT * FROM appointment WHERE pid = ? AND scheduleid = ? AND appodate = ?";
                $stmt_existing = $database->prepare($sql_existing);
                $stmt_existing->bind_param("iis", $userid, $scheduleid, $date);
                $stmt_existing->execute();
                $existing_rows = $stmt_existing->get_result();

                if ($existing_rows->num_rows > 0) {
                    // If the patient already has an appointment scheduled, show a message
                    header("location: appointment.php?action=booking-not1&titleget=none");
                } else {
                    // If there is no overlapping appointment and the patient doesn't already have an appointment scheduled, insert the new appointment into the database
                    $sql2 = "INSERT INTO appointment(pid,scheduleid,appodate) VALUES ($userid,$scheduleid,'$date')";
                    $result = $database->query($sql2);
                    header("location: appointment.php?action=booking-added&titleget=none");
                }
            }
        }
    }
?>
