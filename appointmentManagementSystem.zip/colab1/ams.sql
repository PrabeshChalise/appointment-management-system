-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2023 at 03:30 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ams`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `pid` int(10) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `pid`, `scheduleid`, `appodate`) VALUES
(5, 4, 10, '2023-03-31'),
(7, 4, 10, '2023-03-31'),
(17, 1, 10, '2023-04-26'),
(16, 1, 9, '2023-04-26'),
(19, 1, 12, '2023-04-26'),
(12, 2, 10, '2023-03-31'),
(18, 1, 11, '2023-04-26'),
(22, 1, 13, '2023-05-02'),
(35, 2, 20, '2023-05-09');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `subject`, `message`) VALUES
('prabesh chalise', 'prabesh121@gmail.com', 'hello', 'please help'),
('prabesh chalise', 'prabesh121@gmail.com', 'hello', 'please help'),
('prabesh', 'prabesh@gmail.com', 'need help', 'hello'),
('Prabesh Chalise', 'np03cs4s220296@heraldcollege.edu.np', 'need help', 'abc'),
('Prabesh Chalise', 'np03cs4s220296@heraldcollege.edu.np', 'need help', 'abvc'),
('saurav', 'saurav@gamil.com', 'need help', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL,
  `image` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docid`, `docemail`, `docname`, `docpassword`, `specialties`, `image`) VALUES
(29, 'soniya12@gmail.com', 'soniya', 'soniya123', 14, 'https://images.theconversation.com/files/304957/original/file-20191203-66986-im7o5.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1200&h=1200.0&fit=crop'),
(21, 'rishav1@gmail.com', 'rishav', '123', 1, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEA8QEBAPDw8QDhAPEA0PDxAOEBAPFREWFhUSFhYYHiggGBolGxcVITEhJSkrLi4uFx8zODMtNygtLi0BCgoKDg0OGhAQGi0gHyUtLSsuMistNi0tKy8tNS0tLS0rLSs1LS0tNy0tLS0tLS0tLS0tLS0tLS0tLS0rLTcvLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xAA+EAACAQIDBQUFBwEHBQAAAAAAAQIDEQQSIQUxQVFhBhNxgZEiQqGxwQcUIzJSctGSFTNio8Lh8CQlY3OC/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAEDBAIF/8QAIREBAQACAgICAwEAAAAAAAAAAAECAxEhEjEEEzJBQiL/2gAMAwEAAhEDEQA/APcAAAAAAAAAAAAAAAAAAAALdWrGEXKcowildyk1GKXNt7gKweU9svtXUJOhgWk9U8XOHea/+OO5+MvQ5jAfajtJSXeYinUg73vh6alB6a2SV1039Tz5R7mFe+g8ywP2uU5Ol3mHtHI3XqQmvZkmksqlvW96vdY9A2VtXD4qHeYerCtC9m4Pc99mt6fiWWV5uNjNABUAAAAAEAAAAAAAAgAAAABWAAAAAAAAAAAAAAAAAADPFPtU7S161athY1IwwtCVp0YpKpVnDVylJ8L2SS8ddD2tnzV2gnOtiKuWOapWrO1L3s0nu9TxneGmvHlzuFqrPFO+VRulTjxeumXe/EuYnFwnplWZflqpOMvCa+uv8dtsD7M8TKblXlGhGV7qLU5O/Raep09P7K8BBX/ElLi3K1/JIy8o6PCvHqj9m2kXG2nN8LeXzOt+zPtEsDi4yqSao1EqdW2vst6TfPK9dOvM7vG9gsDKK/DtKKSjNNqSt1OB7S7AnhKsF7LpVfyyyJtWaunz3kmztctXT6Kp1FJKUWpRkk1JO6ae5plRr+z9B08LhoN3y0Ka/Ll91aW4cjYHS4qAACASQAAAAgkAQCSAAAAAACsEkAAAAAAAAAAAAAAAAADxnGbP/wC+VIQVvxu9g1azTu3bw9peR7McPtHZsv7Rw1VQWWDrQlNLXWMpLM+Tcpf8Zlt9N9E7rZ1cZTpyUZ1KcJNbpTjFvrZl6U72aaafFNNGi2/seVfM4woO6lfvKMajbto23ryMHslsOeFc01GNNpPJGOT2rK7sna1720Ofydkx/bebRx9Ggr1q1OkuHeTjG/hfec7tKVDF1tmShOFalLGxh7LUk3dSfwT9TAxvZytWxM67lDNnlkfcQqWp+6ryd787fA6LC4Kbq4BStJ0sUpSeVLTu562XWwxs5M8bw7wAHa+YAAAAAIAAAAMAQSQAAAAAAXCCQBAJAEAkgAAAAAAAAAAABhbQwqac1pKKv42M0pqWs77rO/oSzmLjbL05vHY3JuTbeiX8vgYtTGqGsoyd1rJRbUfJalG0JxalCSzJ6OLV047tV4GseHjRX4bbpvVU55pqF+C1ul03I4re31NclnCY7V1zxhKMNIpVLQztvSye59DqdgxjU/EaeaFrX3xck7+dvmcQ8FS7yOJnFTqxWWm8tlTi9+VcG+e/qehbCwrp0Vm/PP25dLrRHvTOcuWXysvHHhsAAdb54AAAAAgAAAAAIAAAAAAALgAAAACCQABBIAgEkAAAABDdiiVTkBcOZxuPqYytjcHh2oww+FlTqV+H32rG9OmnwyR9qX748tdptbaEcPQr4if5aFGpWl4Qg5NfA1nYbBSo4Kj3utevF4rES/ViKz7yfo5JeEUOFnTWbSpzleM45Kkfg+a5o1S2nKn7M4O9vzRtZ/x4HZdocVhqcF38ssnfIorNUfguXjoc/gcHhcTNR76PtLN3aUoTn/h9pWvzSv8AU5MtOyXruO7DfhZzeq12y5vGV4xhFqFN3nP3V9L8l9De4rbdTB7QpU6rzYLFqFOlN6fd8XuVJv8ATUS05S095W3WGwUKUVCnBQivdirefV9TB21sWGMoV6NS6jUjlUl+aE07xqRfCUZWa8DfXh4xzbdnnXQxknuJOd7H7SniMNGVXTE0Zzw2JS0X3ilLLKSXKWk10mjewrc/VGjFdATAAAAQCWQAAAEAAAAAAAAuAAAAAAAAAAAQSQAIkyS3NgUNAk1PaSeI7nJhrxq1pxpd8sr+7wf561nvaSdlr7TjwuVXP/aTtim8NWwNNVa9et3UatHD0auIlTw7qx72U8iaj7Ckknq2dPs/aFHEUqVbDzjOnKMskldJNaOMouzTTVmnZppop2LselhKUaVFOKWspOTlOc3vnOT1nJ8WzUdjqNRLHSnTlSjU2piKtKnJWapyp01e3C8lOXmBidrNlqMO/vKdWU4xnJy3xtJqKW6KXBLmzWdkcFRxVSdScXJ0ZRUISvHJPfm8d3Q3HbXFf3VFcfxJeG6P+owewSy1sSuEo05eacka9/W8f07WN9z168fMrivQpK3yRi91zGxoKG09qUkvZnDBYuz1WedOdKT/AMiJ01jm9jwvtXak/wBNDAUH4qNWo/hUR0pREW0X4TuY03u6v6XK6Ts11IjIAABkEkAAABAAAAAAAALhBJAAAAAAAAAAAACxJ7y8zHb+IExZajHNPNwjdJdU9X6/Iic2t296LxfHy3+RepxSVluSSXgiisxMJFqmm9W5OX9V3b4l/Eu0Jc8rS8XoviyGrR8GvTMgPP8AtFWz4mq76JqC/wDlW+dzL7GR/wCoqvh3S9cxo62IcpSkrayk31u7m+7Gf3taXKlHTzf8HRnOMOGeP5OzitfIrZTSi0td71f8FGIk/ZSdryUb77cfpbzOdo5zsk82K21Pj/aUKflDBYdL5s6ZsxaeGp0c84RUe8qKVSySzzlaOdvjLdryRkS59AqiW+Pi38GVOepahK7vy0/kqo63l6eBBnAppvRFQRAAAAAAQAAAAAAAVgAAAAAAAAAAAAKKjMe5dqPUsST4FFivUyyTbsknv5u3+5lOskrvjbcnLh0MPEK/RozIRtGKWlklbyCqZvM1a+VNSbatdrVJedn5E10+7mlvySt420JsXEwjx+nPRHW9iIXnW5KNL5zf0OSqwyVqtO35K1SH9M2jvOxNG1Gc/wBdR2/bFJfPMdGz8WePt0haqwUk09zKpsxq+KUJwp8Z8b7t/wDBzWye22ONvpZlgpXV6k5xTulJ3t/PmNo4nu4c22oxXNszGzl+01Wp94wMYWyOs1UvyyS0KjdU08sY8Zb303sznokloYmF1k+iUfq/oZU2BfoPQuFnDy3l4iAAAEAAAAAAAAAAVgAAAAAAAAAAAAMepLo/S5YnUtwl6My5ltrmUY9H25Wb08DJnvLKTjJcr7y9Pf5gQECAPMu09Hu8fXXCco1Ev3RTb/qzHd9naeTC0VxcFP8Arbn9Tk/tCw9sTQqL36LhfrCV/wDWdtRp5YwgvdjGN+iVjXO/5jzJ2vQ5mh7S5oulVje+ZQ03p3umvj6GdtLH908ragrb3vl4GsqYiVSOa0mtbKScfNJnFuznHi7vj67LMv02tDHKcU9z4rqYW0knaXKrBrp7t/ia+GJlC73p71ua6mwwEVXbvJWSd4+8rp2fr8jTXslnftls13G8z0ztnvTesz9q11fVmW+qNfhtkQi80m6k+MpKKvbdpwt0M9w0VpNLrr8TRirpKz0Mk17U1dqSfJOPwZnUpXSb5ERUAQAAAAAAACAAJIAuAAACABIIAEggASCABTMosXGjFxuKhRp1KtSWWnThKpOT92EVdv0AmquK4EuonquOpzWH2nOvCFVtwU4qcaalpBPdF23u1rszcNi2kk76aX6Gc2428N8vj5SctymQy3QqqSutSqTNWLSdqsA633NpXyY2lm/9crqXyibuKtdsb/n5lubzacC8o1m0pTunFw1/W2rLmrbzDk9LSqpv/DG3grO5t8bQU4uLUX+5XRrJYZwVoqnH9sbfJHLs123p26tuMx7aivUsvMtYDaLoV6MpXUZ1I0mulR5V6ScX5GbWwTbvdeCWlzi9tUdqVJKnToU6ic1krQvDK76Od37NvQ8fVlLK9/bhlLHsKZS+hFO9lffZX8S5CDZ2PnqYK7S57zLLdGnbV7/kXCAAAAIAAAAAAAAAFYAAAAAAAAAAAAAartFs/wC8UalK9o1IpNrpJP0djagLLw4qng3h4wpPW0Ek3xS0sX1Cbj7MZSvyTZ1VWGm5aFu5j9M59umfKvHpzeExk6cknCVpJXTTjJeTN9GWZJrcynGYaM1Z7+DWjXmUYSh3cMqbaXM0wxuPXLPZnjn3xxV2pBuOjs+G5fRk2K2ymR7YqGjGq07304GTcgK1Lw876LzujLp4dO2ZGTYmwGVClzLoQIgAABAAAAAAAAAAAAAVgAAAAAAAAAACAAAAET3Mw2uL3cEgAJT0CJBQZDAApZSAFBcAIzab0XgiogEEkAAAAAIJAEAkAQAAAAA//9k='),
(31, 'xyz@gmail.com', 'xyz', '123', 14, 'https://th.bing.com/th/id/OIP.RPRpZ0mTLLrHDqxz4rhZuwHaHp?w=156&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7'),
(23, 'doctor3@gmail.com', 'doctor3', '123', 1, 'https://images.theconversation.com/files/304957/original/file-20191203-66986-im7o5.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1200&h=1200.0&fit=crop'),
(27, 'abc@gmail.com', 'abc', '123', 5, 'https://img.freepik.com/free-photo/woman-doctor-wearing-lab-coat-with-stethoscope-isolated_1303-29791.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pdob`, `ptel`) VALUES
(2, 'patient2@gmail.com', 'Patient2', '123', 'Nepal', '2022-06-03', '0700000000'),
(3, 'prabesh1@gmail.com', 'hello qwe', 'prabesh123@', 'kapan', '2003-12-12', '9861512152'),
(4, 'prabesh111@gmail.com', 'prabesh chalise', '123', 'kapan, kathmandu', '2003-12-12', '9866666666'),
(5, 'prabesh121@gmail.com', 'prabesh chalise', '123', 'kathmandu', '2003-12-23', '9861512152'),
(6, 'patient122@gmail.com', ' ', '123', '', '0000-00-00', '98000000'),
(7, 'patienttwo@gmail.com', ' ', '123', '', '0000-00-00', '9861512152'),
(8, 'patient32@gmail.com', ' ', '123', '', '0000-00-00', '9861512152'),
(9, 'patienttest@gmail.com', 'patient test', '123', 'kapan', '2003-12-12', '9861512152'),
(10, 'prabesh2222@gmail.com', 'hari lal', 'prabesh123', 'kathmandu', '2030-12-12', '9861512152'),
(11, 'abc1@gmail.com', 'abc xyz', 'prabesh123', 'Kapan, Kathmandu', '2023-05-04', '9861512152'),
(12, 'prabesh9@gmail.com', 'Prabesh Chalise', 'prabesh123', 'Kapan, Kathmandu', '2003-12-12', '9861512152'),
(13, 'ram12@gmail.com', 'Ram Kumar', 'ram123', 'kathmandu', '2003-08-23', '9812354678');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `docid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `docid`, `title`, `scheduledate`, `scheduletime`) VALUES
(10, '1', 'hello', '2025-12-22', '22:20:00'),
(9, '2', 'please be on time', '2023-12-03', '22:30:00'),
(11, '2', 'one', '2030-12-02', '22:20:00'),
(12, '2', 'two', '2030-12-21', '22:20:00'),
(13, '20', '123', '2023-05-04', '21:09:00'),
(14, '18', 'abc', '2023-05-05', '21:05:00'),
(15, '22', 'xyz', '2023-12-12', '21:15:00'),
(18, '27', 'aaa', '2023-05-31', '12:01:00'),
(19, '28', 'new session', '2023-05-18', '12:12:00'),
(20, '29', 'abvc', '2023-05-15', '12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `sname`) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clinical biology'),
(8, 'Clinical chemistry'),
(9, 'Clinical neurophysiology'),
(10, 'Clinical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology');

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@gmail.com', 'a'),
('soniya12@gmail.com', 'd'),
('prabesh2222@gmail.com', 'p'),
('patient2@gmail.com', 'p'),
('abc1@gmail.com', 'p'),
('prabesh22@gmail.com', 'd'),
('doctor4@gmail.com', 'd'),
('doctor3@gmail.com', 'd'),
('prabesh123@gmail.com', 'p'),
('prabesh1@gmail.com', 'p'),
('prabesh111@gmail.com', 'p'),
('rishav2@gmail.com', 'd'),
('abc@gmail.com', 'd'),
('patienttest@gmail.com', 'p'),
('patient32@gmail.com', 'p'),
('patienttwo@gmail.com', 'p'),
('patient122@gmail.com', 'p'),
('prabesh121@gmail.com', 'p'),
('rishav@gmail.com', 'd'),
('prabesh9@gmail.com', 'p'),
('xyz@gmail.com', 'd'),
('ram12@gmail.com', 'p');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docid`),
  ADD KEY `specialties` (`specialties`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `docid` (`docid`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
