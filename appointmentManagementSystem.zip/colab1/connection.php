<?php

    $database= new mysqli("localhost","root","","ams");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>